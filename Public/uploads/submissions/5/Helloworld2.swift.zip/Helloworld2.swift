

print("Hello world")
